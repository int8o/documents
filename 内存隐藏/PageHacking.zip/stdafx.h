#pragma once
#include <ntddk.h>
#include <stdio.h>
#include <stdarg.h>
#include <wchar.h>
#include <ntddscsi.h>
#include <srb.h>
#include <ntimage.h>
#include <windef.h>

typedef struct _KAPC_STATE {
	LIST_ENTRY  ApcListHead[2];
	PKPROCESS   Process;
	BOOLEAN     KernelApcInProgress;
	BOOLEAN     KernelApcPending;
	BOOLEAN     UserApcPending;
} KAPC_STATE, *PKAPC_STATE;

NTKERNELAPI
	VOID
	KeStackAttachProcess (
	__inout PEPROCESS PROCESS,
	__out PKAPC_STATE ApcState
	);

NTKERNELAPI
	VOID
	KeUnstackDetachProcess (
	__in PKAPC_STATE ApcState
	);

NTKERNELAPI
	NTSTATUS
	PsLookupProcessByProcessId(
	__in HANDLE ProcessId,
	__deref_out PEPROCESS *Process
	);